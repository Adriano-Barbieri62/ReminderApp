# ReminderApp (Hatırlatıcı) - Kullanım kılavuzu

<html lang="tr">

ReminderApp (Hatırlatıcı) ile artık unutmak yok!    
İçiniz rahat olsun, bu programla, ilaçlarınızı alın, randevunuzu veya birisinin ziyaretini unutmayın, bebek bakıcısı, ev yardımcısı, hemşire vb. gibi hatırlatmalar sayesinde size önemli olan her şeyi hatırlatıyor. ).    
Doğum günü hatırlatıcıları bile!    
Hepimiz hayatımızda en az bir kez bu utanç verici anı yaşamışızdır: Sevdiğimiz birinin doğum gününü unutmak! Tanımaya alışkın olduğunuz tüm insanların (özellikle geniş bir aileden geliyorsanız veya geniş bir arkadaş grubunun parçasıysanız) doğum günlerini hatırlamanın her zaman kolay olmadığını söylemeliyim.    
Tüm ailenin doğum günü tarihlerini giriyorsunuz ve program, yıl dönümü hatırlatmaları da dahil olmak üzere her yıl bir alarmla size bunları hatırlatacak!    
Bu program aynı zamanda bir adres defteri ve keşfedilecek çok daha fazlasını içerir!    

Daha fazlasını öğrenmek ve bu programı yapılandırmak için lütfen bu belgenin tamamını okuyun. Teşekkürler.    

# Kullanım Kılavuzu

* Yazar: [Adriano Barbieri](mailto:adrianobarb@yahoo.it)
* Son değiştirilme tarihi: Kasım 2024

## İçindekiler

* [1.\ giriş](#toc1)
* [2.\ Programın kurulması](#toc2)
* [3.\ Menüler](#toc3)
* [4.\ "Seçilen gün için hatırlatıcı:" seçeneği için ana pencereye ilişkin ek bilgiler](#toc4)
* [5.\ Adres defteri nasıl çalışır?](#toc5)
* [6.\ Program sistem tepsisinden nasıl açılır?](#toc6)


---


# 1.\ Giriş <a name="toc1"></a>
Ajanda ve adres defterinin bir kombinasyonu olan bu programı ben ReminderApp (dahili isim) olarak adlandırdım ancak gerçekte program penceresinde ve durum çubuğunda “Hatırlatıcı” adı ile görünüyor.    

ReminderApp programı taşınabilir ve Windows başladığında otomatik olarak simge durumuna küçültülüp çalışacak şekilde yapılandırılabilir.    

Bu program çok sezgiseldir ve fazla açıklama gerektirmez, ancak size takip etmeniz gereken bazı yönergeler vereceğim.    

# 2.\ Programın kurulması <a name="toc2"></a>
ReminderApp.zip dosyasını edindiyseniz, dosyayı örneğin şu yola çıkartın:    
'C:\Program Dosyaları\ReminderApp'

Ayrıca `C:\` diskinin kök dizinine de çıkarabilirsiniz, örneğin:    

`C:\ReminderApp` Gibi.    

İstediğiniz zaman.    

Bu dosya ayıklandıktan sonra aşağıdaki öğeleri içerir:    

* Aktif olan geçerli dil için Kullanıcı kılavuzu dosyalarını içeren “Doc” klasörü (mevcuttur).    
* Program için mevcut arayüz dil çeviri dosyalarını içeren "locale" klasörü.    
* Alarm ses dosyalarının bulunduğu "Sounds" klasörü, "wav" formatında olduğu ve süreleri 2 saniyeden az olduğu sürece doğrudan bu klasöre ekleyebilirsiniz, ReminderApp otomatik olarak isimleri yükleyecek ve ekleyerek sıralayacaktır. bunları "Bildirimleri ayarla" ayarlar seçeneğine ekleyin; bu, alarm eklerseniz ayarladığınız alarmların sayısının değişebileceği ve bunu Ayarlar Menüsü Alt Menüsü Alt+s'de ve ardından altındaki "Bildirimleri ayarla" iletişim kutusunda sıfırlamanız gerekeceği anlamına gelir. liste açılır menüsü şu şekilde adlandırılır: Alarmı kullan: ardından alarmın adı gelir.    
"Sounds" klasörü içerisinde "Örnekler" klasörü de bulunmaktadır, bu sesler program tarafından kullanılmaktadır.    
* "ReminderApp.exe" dosyası (programın herhangi bir zamanda başlatılmasını sağlayan yürütülebilir dosya).    
* ReminderApp.ico dosyası (ICO dosya formatı Microsoft Windows işletim sistemi tarafından yönetilir, bu format favicons için de yaygın olarak kullanılır. Bu simge, program küçültüldüğü anda görev çubuğunda görünür ve program kapatıldığında kaldırılır) başvuru).    

# Uyarı

ReminderApp.zip dosyası çıkarıldıktan sonra, ReminderApp.exe adlı yürütülebilir dosyayı içerecektir ve bu dosya, onu ilk kez çalıştırdığınızda antivirüsünüz tarafından yanlış pozitif olarak ilan edilecektir!    

Bu, örneğin Windows Defender antivirüs uygulamasında olur.    

Windows Defender Antivirus'ün programı yine de çalıştırmasına nasıl izin verebilirim?    

Programın daima Windows Defender ile çalışmasına izin vermek için "Ek bilgiler" seçeneğine tıklamanız gerekir. Daha sonra "Yine de çalıştır" düğmesi görünür, programı Windows'ta çalıştırmaya başlamak için tıklamanız yeterlidir.    

Bu işlemin, yeni ReminderApp.exe yürütülebilir dosyasının ReminderApp klasörüne her yüklendiğinde yapılması gerekir.    

# 3.\ Menüler <a name="toc3"></a>
Başlangıçta programın ana penceresinde, ilgili komutlarıyla birlikte aşağıdaki beş menüyü bulacağız.    

# Dosya Menüsü Alt Menüsü var Alt+ D

Bu ilk menüde aşağıdaki seçenekler bulunuyor:    

* Adres defteri kişilerini dışa aktar... Ctrl+Shift+e    
Enter tuşuna basın, aşağıdaki ad ile bir iletişim kutusu görünür:    
'Kişileri dışa aktar'    
Düzenleme alanında listenizin konumunu ve dışa aktarma adını seçin:    
'Dosya adı'    
Daha sonra belge türünde txt veya json'u belirtin.    
`Tür: Metin dosyaları (*.txt)`    
Bulmak için aşağı ok:    
'JSON dosyaları (*.json)'    
Son olarak düğmeye basarak dosyanızı kaydedin:    
'Kaydet'    
Her şey yolunda giderse aşağıdaki mesaj görünecektir:    
"Dikkat!" Kişiler başarıyla dışa aktarıldı!`    
* Kişileri adres defterine aktar... Ctrl+Shift+i    
Enter tuşuna basın, aşağıdaki ad ile bir iletişim kutusu görünür:    
`İçe aktarılacak dosyayı seçin`    
'Dosya adı'    
Daha sonra dosya türünde txt veya json'u belirtin.    
`Dosya Türleri: JSON Dosyaları (*.json)`    
Bulmak için aşağı ok kullanın:    
v    
Daha önce dışa aktarılan txt veya json dosyasını seçin ve ardından düğmeye basarak açın:    
`Aç`    
Her şey yolunda giderse aşağıdaki mesaj görünecektir:    
"Dikkat!" İçe aktarma başarıyla tamamlandı!`    
'Tamam' düğmesine basın, şu adı taşıyan yeni bir iletişim kutusu görünür:    
'Nasıl devam edeceğinizi seçin'    
`Evet seçildiğinde kişilerin üzerine yazılacaktır.'    
`Hayır'ı seçtiğinizde yalnızca mevcut olanlara eklenecekler.'    
Seçiminize bağlı olarak Evet veya Hayır düğmesine basın.    
BİLGİNİZE    
Bu programda JSON dosyaları bir veri listesi şeklinde yapılandırılmıştır, örneğin: ["...", "...", "..."] ve programın yönetimi için daha uygundur. metin dosyalarında yeni bir satır işaretçisi ile yapılandırılmışlardır, örneğin satır\nsatır\nsatır vb., bunlar daha okunaklıdır.    
* Çık  Alt+f4    
Bu seçenek, Windows başlatıldığında yapılandırmadığınız sürece, yürütülebilir dosya (ReminderApp.exe) aracılığıyla bir sonraki yeniden başlatma işlemine kadar programı kapatır.    

# Düzenle Menüsü Alt menüsü var Alt+ e

Bu ikinci menüde aşağıdaki seçenekleri görebiliyoruz:    

* Hatırlatıcı ekle... Ctrl+n    
* Hatırlatıcıyı düzenle... F2    
* Hatırlatıcıyı taşı... Ctrl+F2    
* Hatırlatıcıyı sil... Del    
* Ek hatırlatıcı notları (Alt menüsü var) 3 öğeyle:    
* Ekle... Ctrl+Shift+1    
* Düzenle Ctrl+Shift+2    
* Sil Ctrl+Shift+3    
Bir hatırlatıcıya not eklerseniz, ReminderApp_config /ReminderApp_notes klasörüne kaydedilecektir.    
Notların dosya adında benzersiz bir numarası vardır, ör. "Notes_xxxx.txt", program bu nedenle bunları bulabilir ve yönetebilir.    
Not: İletişim kutusunda, Yıldönümü veya Doğum Günü eklerken ayrıca bir melodi seçebilir ve açılan kutudaki düğme aracılığıyla onu Oynatabilir/durdurabilirsiniz.    
Melodiler Sounds, Samples, Melodies klasöründe saklanır ve .wav formatındadır.    
Aynı biçimde ve kısa süreli olmak şartıyla daha fazlasını ekleyebilirsiniz.    
Aynı günde birden fazla yıl dönümü/doğum günü varsa bunlar tek bir bildirimde gruplandırılacak, dolayısıyla listedeki ilk melodi kullanılacaktır.    
Düzenle menüsüne devam ettiğimizde:    
* Geçmiş randevuları sil... Ctrl+Shift+a    
* Geçmiş ilaçları sil... Ctrl+Shift+m    
* Adres defteri... F4    
Az önce açıklanan seçenekler için bir iletişim kutusu açılacaktır; ekrandaki talimatları izleyin.    
* Geçerli tarihe ayarla Ctrl+Shift+h    
Tarih seçiciyi geçerli tarihe sıfırlayacaktır.    
* Mevcut bildirimi durdur Ctrl+Shift+F1    

#  Görünüm Menüsü Alt menüsü var Alt+ Ö

Bu üçüncü menüde aşağıdaki seçeneklere erişebileceğiz:    

* Doğum günlerini göster F5    
* Randevuları göster F6    
* Yinelenen randevuları göster Shift+F6    
* Yinelenen hatırlatıcıları göster Ctrl+F6    
* Yıldönümlerini göster F7    
* İlaçları göster F8    
* Yinelenen ilaçları göster Shift+F8    
İstediğiniz seçeneği bir listede görüntülemek için Enter tuşuna basın.    
v    
Sekme tuşuna basın ve ardından Kapat düğmesini tıklayın veya bu iletişim kutusunu kapatmak ve ardından ana program penceresine dönmek için Escape veya Enter tuşuna basın.    
Not:    
Bir hatırlatıcı oluşturduğunuzda/düzenlediğinizde ayrıca 2 yinelenen türü fark edeceksiniz: (Yinelenen randevu ve Yinelenen ilaç)    
Bu iki tür hatırlatma yinenelenebilir olarak ayarlanabilir: (Her gün, haftada bir, Yılda bir), Haftada bir için haftaya bağlı olarak, Yılda bir için gün seçimi ve ay seçimi etkinleştirilecektir.    
5 ila 60 dakika arasında ayarlayabilirsiniz, zamanında bilgilendirileceksiniz ve ne bileyim değiştirme, hazırlanma fırsatınız olacak ve uyarı sona erdiğinde gerçek alarm çalacak.    
Yinelenen hatırlatıcılar akıllıdır; süreleri dolduktan sonra bir sonraki eşdeğer tarihe geçerler. Örneğin, yinelenen bir günlük hatırlatıcı, onu her zaman ertesi gün de bulursunuz, vb.    
Yinelenen hatırlatıcıları silme seçeneğini eklemedim (belli nedenlerden dolayı), ancak bunları Görünüm menüsünden görebilirsiniz. Birini silmek istiyorsanız, Ayarlar'dan etkinleştirerek gördüğünüz tarihi Görüş, Görüntülenen listelerde ilk "Tarih" sütununu göstermeniz, (Randevular ve ilaçlar hariç) Ardından menü aracılığıyla silmek istediğiniz yinelenen hatırlatıcının türünü görüntülemeniz yeterlidir. "Görünüm" menüsünde aynı adı taşıyan öğeyi seçin ve giriş tarihinin artık soldaki ilk sütunda göründüğünü not edin. Son olarak ana seçicide bu tarihi ayarlayın, böylece görebilir ve silebilirsiniz.    
Görünüm menüsüne devam ediyoruz:
* Görüntülenen listelerde ilk "Tarih" sütununu göster (Randevular ve ilaçlar hariç) (varsayılan olarak işaretli değildir)    
Bu tarihleri ​​görmek, ana seçiciden tarihi ayarlayarak bunları değiştirmeye veya silmeye yönelik hatırlatıcıları kolayca bulmak için kullanışlıdır.    

# Ayarlar Menüsü Alt menüsü var Alt+ A

Bu dördüncü menüde aşağıdaki seçeneklere sahibiz:    

* Bildirimleri ayarla Ctrl+Shift+n    
Enter tuşuna basın, bir iletişim kutusu görünür, kontroller arasında geçiş yapmak için "Sekme" ve "Shift+Sekme" tuşlarını kullanarak, parametre değerini değiştirmek için yukarı ve aşağı ok tuşlarını kullanarak hareket edin.    
`Yineleme sayısı: 3`    
`Yinelemeler arasındaki geçen süre (saniye): 8`    
`Kullanılan Alarm: Alarm 01`    
`24 Saat biçimini etkinleştir`    
Bu, formatın 24 saate mi yoksa 12 saate mi ayarlanacağını seçmek için kullanılan bir onay kutusudur; varsayılan 24 saattir.    
12 saatlik biçimi ayarlamak için boşluk çubuğuna basın.    
`Tarihi Avrupa biçiminde okumayı etkinleştir`    
Bu, tarih biçimini ABD veya Avrupa olarak ayarlamayı seçen bir onay kutusudur; varsayılan Avrupa'dır.    
ABD biçimini ayarlamak için boşluk çubuğuna basın.    
Bu iletişim kutusu aynı zamanda şu onay kutularını da içerir:    
* Windows başladığında otomatik çalıştır (varsayılan olarak işaretli değildir)    
Bu seçeneğin seçilmesi, Windows başlatıldığında programın otomatik olarak başlatılmasına imkan verir.    
* Başlangıçta programı simge durumuna küçült (varsayılan olarak işaretli değildir)    
Programı başlangıçta simge durumuna küçültmeyi seçerseniz, program sizi rahatsız etmemek için görev çubuğunda gizlenecektir, simgesini görmelisiniz, kesinlikle gizli simgelerde, istediğiniz zaman içerik menüsüyle etkileşime geçebileceksiniz. ancak program günün hatırlatıcılarını izlemeye devam edecektir.    
Simgenin her zaman görev çubuğunda görünmesini istiyorsanız, bunu Windows ayarlarından, özelleştirmelerden, Görev Çubuğundan, tüm uygulamaları göster ayarından ve ReminderApp'ı etkinleştirerek gizledikten sonra yapabilirsiniz.    
* Program simge durumuna küçültülmüşse, başlangıçta hatırlatıcı önizlemesini göster (varsayılan olarak işaretlidir)    
Program başlangıçta sistem tepsisinde simge durumuna küçültüldüğünde, günün hatırlatıcılarının bir önizlemesini açar.    
* Güncellemeleri Denetle (varsayılan olarak seçilidir)    
Bu seçenek etkinleştirilirse başlangıçta program güncellemeleri otomatik olarak denetler.
Yapılandırma tamamlandıktan sonra değişiklikleri onaylamak için Enter'a veya "Tamam" düğmesine basın. Değişiklikleri iptal etmek için Escape veya "İptal" düğmesine basın.    
Ayarlar menüsüne devam ediyoruz:    
* Kısayol tuşlarını ayarla Ctrl+Shift+K    
Mevcut bildirimin bir alarm tetiklemesini önlemek ve hatırlatıcıyı (ön planda olmasa bile) göstermek için kullanılan kısayol tuşu kombinasyonları, ReminderApp GUI'sinin dışında çalışacak şekilde tasarlanmıştır.    
Bu, diğer uygulamalarla çakışma olması durumunda bunları ayrı ayrı özelleştirebileceğiniz anlamına gelir.    
Programda halihazırda kullanımda olan bir kombinasyon oluşturursanız hata sesiyle uyarılırsınız ve kabul edilmez.    
Yeni kombinasyonunuz geçerliyse başlık çubuğunda görünecektir, daha sonra "Bu kombinasyonu kullan" düğmesine tıklayabilirsiniz ve siz onu tekrar değiştirmeye karar verene kadar kullanılacaktır.    
* Dili ayarla Ctrl+Shift+L    
Bu öğede Enter tuşuna bastığınızda, bazı dillerin bulunduğu bir iletişim kutusu açılır ve çeviri yerel klasörde mevcutsa etkinleştirilir).    
Bu iletişim kutusunda görüntülenen mevcut diller arasından seçim yaparak arayüz dilini seçebilirsiniz.    
Dilin değiştirildiğini ve bu değişikliklerin etkili olması için programın yeniden başlatılması gerektiğini bildiren bir iletişim kutusu görüntülenir.    

# Yardım Menüsü Alt Menüsü var Alt+ Y

Bu beşinci ve son menüde aşağıdaki seçeneklere sahibiz:    
* Program Hakkında... F1    
Bu öğede Enter tuşuna bastığınızda, program bilgilerinin, varsa kendi dilinizde salt okunur bir düzenleme belgesinde görüntüleneceği bir iletişim kutusu açılacaktır.    
Metinde gezinmek için ok tuşlarını kullanın.    
İşiniz bittiğinde, Sekme tuşuna basın ve ardından Tamam düğmesine tıklayın veya bu iletişim kutusunu kapatmak ve ardından ana program penceresine dönmek için Enter veya Escape tuşuna basın.    
* Kullanım kılavuzu... Shift+F1    
Bu öğe üzerinde Enter tuşuna bastığınızda, varsayılan tarayıcıda, varsa kendi dilinizde program yardımını salt okunur bir düzenleme html belgesinde görüntüleyen bir pencere açılacaktır, aksi takdirde bir uyarı mesajı alacaksınız.    
Kapatmak için Alt+F4 tuşlarına basın.    
* Klavye Kısayol Tuşları... F9    
Bu öğede Enter tuşuna bastığınızda, programın klavye kısayollarının salt okunur düzenleme listesinde görüntüleneceği bir iletişim kutusu açılacaktır; listede gezinmek için ok tuşlarını kullanın.    
Sekme tuşuna basın ve ardından Kapat düğmesini tıklayın veya bu iletişim kutusunu kapatmak ve ardından ana program penceresine dönmek için Escape veya Enter tuşuna basın.    
* Güncellemeleri Denetle... Ctrl+Shift+U    
Bu öğede Enter tuşuna bastığınızda program için güncelleme olup olmadığı size bildirilecektir, varsa ekrandaki talimatları izleyin.

# 4.\ "Seçilen gün için hatırlatıcı:" seçeneği için ana pencereye ilişkin ek bilgiler <a name="toc4"></a>
Ana pencere seçicide tarihi değiştirdiğinizde, seçilen tarih bir hatırlatıcıyla eşleşiyorsa bir sonar sesi duyulacaktır.    
Ancak daha önce bir hatırlatıcı seçilmişse odak listeye kayabilir.    
Bu rahatsızlıktan kaçınmak için, devam etmeden önce hatırlatıcının seçimini kaldırabilir veya sistem dil ayarlarına bağlı olarak (programın dil ayarlarına değil) ajanda günü, ay, yıl veya ay, gün, yıl tarihinden hemen sonraki tarihi girebilirsiniz.    
Seçicide Sağ/Sol okları kullanarak gezinebilirsiniz.    
NVDA gibi ekran okuyucu kullanıcıları için, ikincisinin seçicideki mevcut konumu söylemediğini unutmamak önemlidir. Yukarı/Aşağı oka basmanızı öneririz: 
NVDA, belirlediğiniz tarihi bildirecek ve siz tam gün, ay veya yılı yazdığınız anda güncellemeler sağlayacaktır.    
Sonar, başlangıç ​​tarihini ayarlama sorununu çözüyor, o tarihte hatırlatıcılar listesine odaklanmak yerine, sizi bilgilendiren sesi duyuyorsunuz ve tarihinizle sorunsuzca oynayabiliyorsunuz :)    

# 5.\ Adres defteri nasıl çalışır? <a name="toc5"></a>
Erişmek için:    
`Düzenle Menüsü Alt menüsü var Alt+ e`    
Daha sonra:    
`Adres defteri... F4`    
Bu seçenekte Enter tuşuna bastığınızda şu adı taşıyan bir iletişim kutusu açılır:    
`Adres defteri`    
Bu iletişim kutusu, eklediyseniz kişilerinizin listesini içerecektir, aksi halde bu liste boştur.    
Bu iletişim kutusundaki içerik menüsünü çoğu klavyede sağ kontrol tuşunun solunda bulunan uygulama tuşuna basarak açtığınızda. Uygulama tuşu olmayan bir klavyede bunun yerine Shift+f10 tuşlarına basın.    
Bağlam menüsündeki içeriğe bağlı olarak bazı seçeneklerin kişi listesinde kullanılamayacağını lütfen unutmayın. İstediğiniz seçeneğin üzerinde Enter tuşuna basabilirsiniz; seçenekler şunlardır:    

* Kişi ekle... Ctrl+N    
* Kişiyi düzenle... F2    
* Kişiyi sil... Del    
* Kişi bul... Ctrl+F3    
Az önce açıklanan menü seçenekleri için bir iletişim kutusu açılacaktır; ekrandaki talimatları izleyin.    
* Sonrakini bul F3    
* Öncekini bul Shift+F3    
Bu seçeneklerin her ikisi de "Kişi bul" iletişim kutusuna yazdığınız kişi adını temel alır, böylece arama, adres defteri listesinde bulunan aynı ismin sonraki veya önceki eşleşmesiyle gerçekleştirilir.    
* Kişiye e-posta gönder... Ctrl+e    
Bu seçenek için bir iletişim kutusu açılacaktır, ekrandaki talimatları izleyin.    

Örneğin kişinin adını düzenlerken, kişinin e-postası başlangıçta (ve gerekiyorsa sonunda) bir boşlukla ayrılmış olarak düzenleme alanına girilmişse, kişiye bir e-posta gönderebileceğinizi lütfen unutmayın. Aksi takdirde, bu düzenleme kutusunda e-posta yoksa, bu seçenek e-postayı göndermek için kullanılamaz.    

Varsayılan bir e-posta programı ayarlamadıysanız, sistem otomatik olarak e-postayı göndermek için kullanılacak uygulamayı seçmenize olanak tanıyan bir iletişim kutusu görüntüler.    

# 6.\ Program sistem tepsisinden nasıl açılır? <a name="toc6"></a>

* Windows+b tuşlarına basarak sistem tepsisine erişin, Aşağı okla “Hatırlatıcı” simgesine gelin ve çoğu klavyede sağ kontrol tuşunun solunda bulunan uygulama tuşuna basarak içerik menüsünü açın. Uygulama tuşu olmayan bir klavyede bunun yerine shift+f10 tuşlarına basın.    
* Windows sistem tepsisinde bulunan "Hatırlatıcı" simgesine sağ tıklayın.    

İçerik menüsü açıldığında, menüde gezinmek için ok tuşlarını ve aşağıda listelenen öğelerden herhangi birini etkinleştirmek için enter tuşunu kullanabilirsiniz.    

* Hatırlatıcıyı Göster    
Bu seçenek üzerindeyken Enter tuşuna basıldığında program görüntülenecektir.    
* Mevcut bildirimi durdur    
Bu seçenek üzerindeyse Enter tuşuna basıldığında mevcut bildirim durdurulacaktır.    
* Adres defteri...    
Bu seçeneğin üzerinde Enter tuşuna basıldığında "Adres defteri" iletişim kutusu açılır.    
* Hatırlatıcıdan çık    
Bu seçenekte Enter tuşuna basıldığında programdan çıkılır.    

---

Bu belgeleri okuduğunuz için teşekkür ederiz!    

ReminderApp (Hatırlatıcı) programını iyi günlerde kullanmanızı dilerim 😉    
Bu belgeleri yazdığı, ReminderApp'in Fransızca, İngilizce, İtalyanca ve İspanyolcaya çevirisini yaptığı ve geri bildirimleri ile önerileri için [Rémy Ruiz](mailto:remyruiz@gmail.com)'a içtenlikle teşekkür etmek isterim.    
[Umut KORKMAZ](mailto:umutkork@gmail.com), Türkçe dil desteği için sana da içten teşekkürler.    

