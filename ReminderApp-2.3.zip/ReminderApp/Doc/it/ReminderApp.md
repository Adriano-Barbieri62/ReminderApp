# ReminderApp (Promemoria) - Manuale dell'utente

Con ReminderApp (Promemoria), niente più dimenticanze!    
Stai tranquillo, questo programma è lì per ricordarti tutto ciò che è importante grazie a promemoria come (ad esempio: prendere le medicine, non dimenticare un appuntamento o la visita di qualcuno, con la baby-sitter, la colf, l'infermiera, ecc.).    
Anche i promemoria dei compleanni!    
Tutti noi abbiamo vissuto almeno una volta nella vita questo momento imbarazzante: dimenticare il compleanno di una persona cara! C'è da dire che non è sempre facile ricordare i compleanni di tutte le persone che si è abituati a incontrare (soprattutto quando si proviene da una famiglia numerosa o si fa parte di un folto gruppo di amici).    
Inserisci i compleanni di tutta la famiglia e il programma te lo ricorderà ogni anno con un allarme, incluso il promemoria di un anniversario!    
Questo programma contiene anche una rubrica per i contatti e molto altro da scoprire!

Per ulteriori informazioni e per configurare questo programma, leggere questa documentazione nella sua interezza. GRAZIE.

Nota: In questo documento è stata adottata una terminologia specifica per utenti che utilizzano ausili informatici per persone non vedenti.

# Guida per l'utente

* Autore: [Adriano Barbieri](mailto:adrianobarb@yahoo.it)
* Ultima modifica: Novembre 2024

## sommario

* [1.\ Introduzione](#toc1)
* [2.\ Impostazione del programma](#toc2)
* [3.\ I menu](#toc3)
* [4.\ Informazioni aggiuntive per la finestra delle opzioni principali "Promemoria per il giorno selezionato:"](#toc4)
* [5.\ Come funziona la Rubrica?](#toc5)
* [6.\ Come aprire il programma dalla barra delle applicazioni?](#toc6)


---


# 1.\ Introduzione <a name="toc1"></a>
Questo programma, che è una combinazione di agenda e rubrica sviluppata da me, l'ho chiamato ReminderApp (nome interno) ma in realtà la finestra del programma e la barra delle applicazioni appaiono con il nome "Promemoria".    

Il programma ReminderApp è portatile e può essere configurato per ridursi a icona ed essere eseguito automaticamente all'avvio di Windows.    

Questo programma è molto intuitivo e non richiede molte spiegazioni, ti darò comunque alcune linee guida da seguire.    

# 2.\ Impostazione del programma <a name="toc2"></a>
Se hai il file ReminderApp.zip, estrailo, ad esempio, nel percorso:    
`C:\Programmi\ReminderApp`    

Puoi anche estrarlo nella radice dell'unità `C:\`, ad esempio:    

`C:\ReminderApp`    

oppure puoi posizionarlo dove vuoi.    

Una volta estratto, questo file contiene i seguenti elementi:    

* La cartella "Doc" contenente i file della Guida del programma per la lingua attualmente in uso (se disponibile).    
* La cartella "locale" contenente i file di traduzione dell'interfaccia linguistica disponibili per il programma.    
* La cartella "Sounds" che contiene i file dei suoni degli allarmi, è possibile aggiungerli direttamente a questa cartella purché siano in formato "wav", e la loro durata sia inferiori a 2 secondi, ReminderApp caricherà automaticamente i nomi e li ordinerà quando li inserirà nell'opzione di configurazione  "Imposta notifiche", il che significa che se aggiungi sveglie, il numero di sveglie impostato potrebbe cambiare e dovrai reimpostarlo nel menu Impostazioni sottomenu Alt+i e poi nella finestra di dialogo "Imposta notifiche" nell'elenco a discesa chiamato : Usa allarme: seguito dal nome dell'allarme.    
C'è anche una cartella "Samples" all'interno della cartella "Sounds", questi suoni vengono utilizzati dal programma.    
* Il file "ReminderApp.exe" (file eseguibile per avviare il programma in qualsiasi momento).    
* Il file ReminderApp.ico (il formato file ICO è gestito dal sistema operativo Microsoft Windows, questo formato è ampiamente utilizzato anche per le favicon. Questa icona è visibile nella barra delle applicazioni nonappena il programma è ridotto a icona e viene rimosso alla chiusura dell'applicazione).    

# Avviso

Il file ReminderApp.zip, una volta estratto, conterrà il suo eseguibile chiamato ReminderApp.exe, che il tuo antivirus dichiarerà falso positivo quando lo eseguirai per la prima volta!    

Ciò accade, ad esempio, con l'antivirus Windows Defender.    

Come posso consentire comunque a Windows Defender Antivirus di eseguire il programma?    

Per consentire al programma di funzionare ancora con Windows Defender, è necessario fare clic su "Ulteriori informazioni". Quindi viene visualizzato il pulsante "Esegui comunque", basta fare clic su di esso per avviare l'esecuzione del programma in Windows.    

Questa operazione deve essere eseguita ogni volta che il nuovo file eseguibile ReminderApp.exe viene installato nella cartella ReminderApp.    

# 3.\ I menu <a name="toc3"></a>
Nella finestra principale del programma all'avvio troveremo i seguenti cinque menù con i rispettivi comandi da tastiera.    

# Menu File sottomenu Alt+ f
In questo primo menu avremo le seguenti opzioni:    
# Contatti sottomenu:
* Esporta i contatti della rubrica... Ctrl+Shift+e    
Premere Invio, viene visualizzata una finestra di dialogo con il nome:    
`Esporta contatti`    
Seleziona la posizione e il nome di esportazione della tua lista nel campo di modifica:    
`Nome file`    
Indicando poi txt o json nel tipo di documento.    
`Tipo: File di testo (*.txt)`    
Freccia giù per trovare:    
`File JSON (*.json)`    
Infine salva il tuo file cliccando sul pulsante::    
`Salva `    
Se tutto è andato bene, apparirà il seguente messaggio:    
`Avviso! Contatti esportati con successo!`    
* Importa i contatti nella rubrica... Ctrl+Shift+i    
Premere Invio, viene visualizzata una finestra di dialogo con il nome:    
`Seleziona un file da importare`    
`Nome file`    
Indicando poi txt o json nel tipo di documento.    
`Tipi di file: File JSON (*.json)`    
Freccia giù per trovare:    
Tipi di file: File di testo (*.txt)    
Seleziona il file txt o json precedentemente esportato, quindi aprilo premendo il pulsante:    
`Apri`    
Se tutto è andato bene, apparirà il seguente messaggio:    
`Avviso! Importazione completata con successo!`    
Premere il pulsante "OK". Viene visualizzata una nuova finestra di dialogo con il nome:    
`Scegli come procedere`    
`Scegliendo Sì, i contati verranno sovrascritti.`    
`Scegliendo No, saranno solo aggiunti a quelli esistenti.`    
Premi il pulsante Sì o No in base alla tua scelta.    
PER VOSTRA INFORMAZIONE    
`I file JSON nel caso di questo programma sono strutturati come lista di dati, es: ["...", "...", "..."] e sono più comodi da gestire per il programma, mentre quelli di testo sono strutturati con un marcatore di nuova linea, es:    
linea    
linea    
linea, eccetera che sono più leggibili da un umano`.    
# Configurazione sottomenu:
* Esporta la cartella di configurazione... Ctrl+E    
Premere Invio, viene visualizzata una finestra di dialogo con il nome:    
`Scegli cartella di destinazione`    
Seleziona la posizione di esportazione della cartella ReminderApp_config nel campo di modifica:    
Freccia giù per trovare:    
Seleziona cartella    
Se tutto è andato bene, apparirà il seguente messaggio:    
`Avviso! Configurazione esportata con successo!`    
* Importa la cartella di configurazione... Ctrl+I    
Premere Invio, viene visualizzata una finestra di dialogo con il nome:    
`Scegli cartella di origine`    
Seleziona la posizione della cartella ReminderApp_config nel campo di modifica:    
Freccia giù per trovare:    
Seleziona cartella    
Se tutto è andato bene, apparirà il seguente messaggio:    
`Avviso! Configurazione importata con successo!`    
* Esci Alt+f4    
Questa opzione chiude il programma fino al successivo riavvio tramite il file eseguibile (ReminderApp.exe), a meno che non l'abbiate impostata all'avvio di Windows.    

# Menu Modifica sottomenu Alt+ m

In questo secondo menu avremo le seguenti opzioni:    

* Aggiungi promemoria... Ctrl+n    
* Modifica promemoria... F2    
* Sposta promemoria... Ctrl+F2    
* Elimina promemoria... Del    
* Note aggiuntive del promemoria (submenu) con 3 voci:    
* Aggiungi... Ctrl+Shift+1    
* Modifica Ctrl+Shift+2    
* Elimina Ctrl+Shift+3    
Se si aggiunge una nota a un promemoria, verrà salvata nella cartella ReminderApp_config /ReminderApp_notes.    
Le note hanno un numero univoco nel nome del file, es: "Notes_xxxx.txt", il programma è quindi in grado di trovarle e gestirle.    
Nota: Nella finestra di dialogo, quando si aggiunge un Anniversario o un Compleanno, è anche possibile selezionare un motivetto musicale e riprodurlo/interromperlo tramite una casella combinata e un pulsante.    
Le melodie sono memorizzate nella cartella Sounds, Samples, Melodies e sono in formatto .wav.    
È possibile aggiungerne a patto che siano dello stesso formato e di breve durata.    
In caso ci siano  più anniversari/compleanni nello stesso giorno, questi verranno raggruppati in una unica notifica, pertanto verrà usato la prima melodia della lista.    
Proseguendo col menu Modifica:    
* Elimina appuntamenti passati... Ctrl+Shift+a    
* Elimina medicine passate... Ctrl+Shift+m    
* Rubrica... F4    
Per le opzioni appena descritte si aprirà una finestra di dialogo, seguire le istruzioni visualizzate sullo schermo.    
* Imposta alla data corrente Ctrl+Shift+h    
Resetterà il selettore della data alla data corrente.    
* Arresta notifica corrente Ctrl+Shift+F1    

# Menú Visualizza sottomenu Alt+ v

In questo terzo menu avremo le seguenti opzioni:    

* Vedi compleanni F5    
* Vedi appuntamenti F6    
* Vedi appuntamenti ricorrenti Shift+F6    
* Vedi ripetizione del promemoria Ctrl+F6    
* Vedi anniversari F7    
* Vedi medicine F8    
* Vedi medicine ricorrenti Shift+F8    
Premere Invio sull'opzione desiderata per visualizzarla in un elenco.    
Premi il tasto applicazioni o Maiusc+F10 per visualizzare le opzioni disponibili.    
Premere Tab e quindi fare clic sul pulsante Chiudi oppure premere il tasto Escape o invio per chiudere questa finestra di dialogo e quindi tornare alla finestra principale del programma.    
Nota:    
Quando crei / modifichi un promemoria, noterai anche 2 tipi ricorrenti: (Appuntamento ricorrente e Medicina ricorrente).    
Questi due tipi di promemoria possono essere impostati con ricorrenza : (Giornaliera, Settimanale, Annuale), a seconda della settimana per Settimanale, si attiveranno scelta del giorno e scelta del mese per Annuale.    
Puoi impostare dda 5 a 60 minuti, verrai avvisato per tempo e avrai modo di , non so, cambiarti, prepararti, e alla scadenza del preavviso scatterà l'allarme vero.    
I promemoria ricorrenti sono intelligenti, si spostano alla datta equivalente successiva al momento che scadono. Ad esempio un promemoria ricorrente Giornaliero, te lo ritroverai sempre anche il giorno dopo, e così via.    
Non ho previsto la possibilità di eliminare i promemoria ricorrenti (per motivi evidenti), ma puoi visualizzarli tramite il menu "Visualizza".    
Se desideri rimuoverne uno, basta attivare la prima colonna "Data" negli elenchi, esclusi appuntamenti e medicine.    
Successivamente, seleziona il tipo di promemoria ricorrente che desideri eliminare dal menu "Visualizza" e prendi nota della sua data di immissione, visibile nella prima colonna a sinistra.    
Infine, imposta questa data nel selettore principale in modo da poterla vedere e procedere con l'eliminazione.    
Proseguendo col menu Visualizza:    
* Mostra la prima colonna "Data" negli elenchi visualizzati, (Esclusi appuntamenti e medicine) (non selezionato per impostazione predefinita)    
Vedere queste date è utile per ritrovare facilmente i promemoria per modificarli o eliminarli, impostando la data dal selettore principale.    

# Menu Impostazioni sottomenu Alt+ i

In questo quarto menu avremo le seguenti opzioni:    

* Imposta notifiche Ctrl+Shift+n    
Premi Invio, appare una finestra di dialogo, muoviti con "Tab" e "Shift+Tab" per spostarti tra i controlli, frecce su e giù per modificare il valore del parametro.    
`Numero di ripetizioni: 3`    
`Intervallo tra le ripetizioni (secondi): 8`    
`Usa allarme: Alarm 01`    
`Abilita la lettura delle ore nel formato 24 ore`    
Questa è una casella di controllo per scegliere di impostare il formato 24 ore o 12 ore, il valore predefinito è 24 ore.    
Premere la barra spaziatrice per impostare il formato 12 ore.    
`Abilita la lettura delle date nel formato europeo`    
Questa è una casella di controllo per scegliere di impostare il formato delle date USA o Europeo, il valore predefinito è Europeo.    
Premere la barra spaziatrice per impostare il formato USA.    
La  finestra di dialogo contiene anche  queste caselle di controllo:    
* Riduci a icona il programma all'avvio (non selezionato per impostazione predefinita)    
Se scegli di ridurre il programma all'avvio, il programma si nasconderà nella barra delle applicazioni per non dare fastidio, dovresti vedere la sua icona, sicuramente nelle icone nascoste, potrai interagire con il menu contestuale quando vuoi. ma il programma continuerà a monitorare eventuali promemoria della giornata.    
Se vuoi che si veda sempre l'icona nella barra delle applicazioni, puoi farlo, una volta nascosto, impostando dalle impostazioni di Windows, personalizzazioni, Barra delle applicazioni, mostra tutte le applicazioni,e attivare ReminderApp.    
* Esecuzione automatica all'avvio di Windows (non selezionato per impostazione predefinita)    
La scelta di questa opzione consentirà al programma di avviarsi automaticamente all'avvio di Windows.    
* Mostra anteprima promemoria all'avvio se il programma è ridotto a icona (selezionato per impostazione predefinita)    
Quando il programma si minimizza nel system tray all'avvio, apre un'anteprima dei promemoria del giorno.    
* Controlla presenza aggiornamenti (selezionato per impostazione predefinita)    
Se questa opzione è attivata, controlla all'avvio la disponibilità di aggiornamenti per il programma.    
Una volta completata la configurazione, premere invio o il pulsante "OK" per convalidare le modifiche. Per annullare le modifiche premere escape o il pulsante "Annulla".    
Proseguendo col menu Impostazioni :    
* Imposta combinazione tasti rapidi Ctrl+Shift+K    
Le combinazioni di tasti rapidi per interrompere l'allarme della notifica corrente e per visualizzare Promemoria (anche quando non è in primo piano) sono progettate per funzionare al di fuori dell'interfaccia grafica di ReminderApp.    
Ciò significa che, in caso di conflitti con altre applicazioni, sarà possibile personalizzarle individualmente.    
Se si crea una combinazione già in uso nel programma si verrà avvisati da un suono d'errore e non verrà accettata.    
Se la tua nuova combinazione è valida apparirà nella barra del titolo, potrai quindi fare invio sul pulsante "Usa questa combinazione" e sarà usata fino a quando non deciderai di cambiarla nuovamente.    

* Imposta lingua Ctrl+Shift+L    
Quando premi Invio su questo elemento, si aprirà una finestra di dialogo in cui sono presenti alcune lingue, che saranno abilitate se la traduzione è disponibile nella cartella locale).    
Puoi scegliere la lingua dell'interfaccia selezionandola tra le lingue attualmente disponibili visualizzati in questo dialogo.    
Viene visualizzata una finestra di dialogo che informa che la lingua è stata modificata e che quindi è necessario riavviare il programma affinché le modifiche abbiano effetto.    

# Menu Aiuto sottomenu Alt+ a

In questo quinto ed ultimo menù avremo le seguenti opzioni:    

* Informazioni sul programma... F1    
Quando premi Invio su questo elemento, si aprirà una finestra di dialogo che mostra le informazioni sul programma in un documento modificabile e di sola lettura nella tua rispettiva lingua, se disponibile.    
Utilizza i tasti NVDA+b o Insert+b dello screen reader nella documentazione per leggere nuovamente queste informazioni.    
Una volta terminato, premere Tab e quindi fare clic sul pulsante OK o premere il tasto Invio o Escape per chiudere questa finestra di dialogo e quindi tornare alla finestra principale del programma.    
* Manuale d'uso... Shift+F1    
Quando premi Invio su questo elemento, si aprirà una finestra che mostra l'aiuto del programma in un documento html modificabile di sola lettura nel browser predefinito nella tua rispettiva lingua, se disponibile, altrimenti riceverai un messaggio di avviso.    
Premere Alt+F4 per chiudere la documentazione.    
* Tasti rapidi... F9    
Quando premi Invio su questo elemento, si aprirà una finestra di dialogo in cui le scorciatoie da tastiera del programma verranno visualizzate in un elenco modificabile di sola lettura; utilizzare i tasti freccia per spostarsi nell'elenco.    
Premere Tab e quindi fare clic sul pulsante Chiudi oppure premere il tasto Escape o Invio per chiudere questa finestra di dialogo e quindi tornare alla finestra principale del programma.    
* Controlla presenza aggiornamenti... Ctrl+Shift+U    
Quando premi Invio su questo elemento, verrà notificata la presenza di aggiornamenti per il programma, in caso positivo, seguire le istruzioni visualizzate sullo schermo.    

# 4.\ Informazioni aggiuntive per la finestra delle opzioni principali "Promemoria per il giorno selezionato:" <a name="toc4"></a>
Quando si modifica la data nel selettore della finestra principale, se la data selezionata corrisponde a un promemoria, verrà emesso un suono di sonar.    
Tuttavia, è possibile che il focus si sposti sulla lista se un promemoria è stato precedentemente selezionato.    
Per evitare questo inconveniente, è possibile deselezionare il promemoria prima di procedere, oppure inserire direttamente la data seguendo l'ordine giorno, mese, anno o mese, giorno, anno, a seconda delle impostazioni della lingua di sistema (e non di quelle del programma).    
Nel selettore si può navigare utilizzando le frecce orizzontali.    
Per gli utenti di screen reader come NVDA, è importante notare che quest'ultimo non vocalizza la posizione attuale nel selettore. Si consiglia di premere una freccia verticale: NVDA comunicherà la data impostata e fornirà aggiornamenti non appena si digita un giorno, un mese o un anno completo.    
Il sonar risolve il problema nell'impostazione della data iniziale, anziché spostare il focus sulla lista dei promemoria quando in quella data ce ne è qualcuno, si sente il suono che ti avvisa di ciò e puoi giocare con la tua data senza problema :)    

# 5.\ Come funziona la Rubrica? <a name="toc5"></a>
Vai a:    
` Menu Modifica sottomenu Alt+ m`    
Poi:    
`Rubrica... F4`    
Quando si preme Invio su questa opzione, viene visualizzata una finestra di dialogo denominata:    
`Rubrica contatti`    
Questa finestra di dialogo conterrà l'elenco dei tuoi contatti se ne hai aggiunto uno; altrimenti questa lista sarà vuota.    
Quando si apre il menu contestuale in questa finestra di dialogo premendo il tasto Applicazioni situato accanto al tasto Control destro sulla maggior parte delle tastiere. Su una tastiera senza tasto applicazioni, premi invece MAIUSC+F10.    
Tieni presente che nell'elenco dei contatti alcune opzioni non sono disponibili a seconda del contesto. Puoi premere Invio sull'opzione desiderata, quindi ecco le opzioni:    

* Aggiungi contatto... Ctrl+N    
* Modifica contatto... F2    
* Elimina contatto... Del    
* Trova contatto... Ctrl+F3    
Per le opzioni di menu appena descritte si aprirà una finestra di dialogo, seguire le istruzioni visualizzate sullo schermo.    
* Trova successivo F3    
* Trova precedente Shift+F3    
Entrambe le opzioni si basano sul nome del contatto digitato nella finestra di dialogo "Trova contatto", quindi la ricerca viene eseguita rispetto alla corrispondenza successiva o precedente con lo stesso nome trovata nell'elenco della rubrica contatti.    
* Invia email al contatto... Ctrl+e    
Si aprirà una finestra di dialogo per questa opzione, seguire le istruzioni visualizzate sullo schermo.    

Tieni presente che puoi inviare un'e-mail al contatto nel caso in cui l'e-mail del contatto sia stata inserita nel campo di modifica separato da uno spazio all'inizio (e se necessario alla fine), durante la modifica del nome del contatto, ad esempio. Altrimenti, se non è presente alcuna email in questa casella di modifica, questa opzione non sarà disponibile per inviarla.    

Se non è stato impostato un programma di posta elettronica predefinito, verrà visualizzata automaticamente dal sistema una finestra di dialogo che consente di selezionare l'applicazione da utilizzare per inviare l'e-mail.    

# 6.\ Come aprire il programma dalla barra delle applicazioni? <a name="toc6"></a>

* Accedere alla system tray premendo Windows+b, freccia giù sino a giungere sull'icona "Promemoria" e aprire il menu contestuale premendo il tasto applicazioni situato accanto al tasto control destro sulla maggior parte delle tastiere. Se la tastiera è sprovvista di tasto applicazioni, premere Maiusc+f10.    
* Fare clic con il tasto destro sull'icona "Promemoria" situata nella system tray di Windows.    

Una volta che il menu appare, è possibile scorrerlo con le frecce direzionali, mentre per attivare uno degli elementi elencati di seguito come sempre è sufficiente premere invio.    

* MostraPromemoria    
Premendo il tasto Invio in questa opzione verrà visualizzato il programma.    
* Ferma notifica corrente    
Premendo il tasto Invio su questa opzione si interromperà la notifica corrente.    
* Rubrica...    
Premendo il tasto Invio su questa opzione si apre la finestra di dialogo "Rubrica contatti".    
* Esci da Promemoria    
Premendo il tasto Invio in questa opzione si uscirà dal programma.    

---

Grazie per aver letto questa documentazione!    

Ti auguro un buon utilizzo del programma ReminderApp (Promemoria ) 😉    
Desidero ringraziare  sinceramente [Rémy Ruiz](mailto:remyruiz@gmail.com) per aver scritto questa documentazione e traduzione di ReminderApp in Francese, Inglese, Italiano e Spagnolo e per i feedback e suggerimenti da lui proposti.    
